<?php
/**
 * Plugin name: Prueba Rest API Woocommerce
 * Plugin URI: http://ginton.onlinewebshop.net
 * Description: Prueba de rest api woocommerce
 * Author: Fran Mellado
 * Author URI: http://ginton.onlinewebshop.net
 * version: 0.1.0
 * License: GPL2 or later.
 */

require __DIR__ . '/vendor/autoload.php';

use Automattic\WooCommerce\Client;

$woocommerce = new Client(
  'https://www.kiransboutique.com/api/api_single_product.php',
  'ck_db71a0659b462927c15aa0b37d3586c9bdaf0cb2',
  'cs_73146ec996037119907c15cec11aef3716645a9b',
  [
    'version' => 'wc/v3',
  ]
);

$products=$woocommerce->get('products');

echo '<pre>';
print_r($products);
echo '</pre>';

?>